<?php
    header("Location: ./view/login-admin.php");
?>